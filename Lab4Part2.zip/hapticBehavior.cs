﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hapticBehavior : MonoBehaviour {
	public GameObject smallSphere;
	public enum typeFunction {Linear};
	public typeFunction mytypeFunction= typeFunction.Linear;
	public falconBehaviour plugin = new falconBehaviour();
	public float radiusOrWidth = 1.0f; 
	Vector3 previousServoPos;
	public float coeffLinear = 1.0f;
	Vector3 currentServoPos;
	Vector3 velocity;
	Vector3 force;
	float distance=0.0F;
	float percentageDistance;
	float coeff;

	void Start(){
		plugin.StartHapticsSystem();
		StartCoroutine(plugin.InitHapticsSystem());
	}

	void OnApplicationQuit (){
		plugin.applicationQuit();
	}

	void Update(){
		transform.localScale = new Vector3(radiusOrWidth + radiusOrWidth, radiusOrWidth + radiusOrWidth, radiusOrWidth +radiusOrWidth);
	}

	void FixedUpdate (){
		currentServoPos= plugin.GetServoPos();
		velocity = (currentServoPos - previousServoPos) /(Time.fixedDeltaTime);
		previousServoPos = currentServoPos;
		force = 10*Vector3.Normalize(transform.position-smallSphere.transform.position);
		distance=Vector3.Distance(transform.position,smallSphere.transform.position);
		percentageDistance = distance/radiusOrWidth;

		if(percentageDistance < 0)
			percentageDistance = 0;

		coeff = 1.0f;

		if(radiusOrWidth - distance > 0)
				coeff = percentageDistance * coeffLinear;

		plugin.SetServo(force * coeff);
		smallSphere.transform.position = currentServoPos;
	}
}
